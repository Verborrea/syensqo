# ADR-001 — Monolito modular

**Estado:** aceptado · 2026-08-07

## Contexto

El backend arrancó como rutas planas (`routes/auth.js`, `routes/patients.js`,
`routes/evaluations.js`) con la lógica de negocio mezclada directo en el handler HTTP.
A pedido explícito, se reorganizó en un patrón de monolito modular: un solo proceso/
deploy, pero con límites internos entre módulos que evitan que el código se vuelva una
maraña a medida que se agreguen funcionalidades nuevas (citas, facturación, etc.).

No se adoptó un framework de microservicios ni se dividió en procesos separados —
seguimos con **un solo proceso Node, una sola base de datos, un solo deploy**. Lo que
cambia es la disciplina interna sobre quién puede tocar qué.

## Decisión

### Módulos

| Módulo | Dueño de | Expone HTTP |
|---|---|---|
| `src/modules/auth/` | Login, verificación de sesión (JWT) | Sí (`/api/auth/*`) |
| `src/modules/doctors/` | Tabla `doctors` (lectura y creación/actualización de cuentas) | No — sin registro público a propósito, solo se usa internamente (por `auth`) y desde `db/create-doctor.js` |
| `src/modules/patients/` | Tablas `patients` y `evaluations` (evaluations va anidado como sub-recurso) | Sí (`/api/patients*`) |

### Código compartido (kernel, no pertenece a ningún módulo)

- `src/lib/` — funciones puras sin I/O: `clinical.js` (cálculos clínicos),
  `validate.js` (validación de entrada), `httpError.js` (helper de errores con status).
- `src/middleware/auth.js` — `requireAuth`, usado por cualquier módulo que necesite
  autenticación.
- `src/db.js` — el único `pool` de Postgres del proceso.

### La regla que importa

**Ningún módulo consulta directamente una tabla que no le pertenece.** Si un módulo
necesita un dato de otro (ej. `evaluations` necesita la altura del paciente, que vive en
`patients`), se lo pide a través de la función pública del `service.js` dueño de esa
tabla — nunca con su propio `pool.query("... FROM <tabla ajena> ...")`.

Ejemplo concreto ya corregido: `evaluations.service.js` llamaba
`pool.query("SELECT height_m FROM patients ...")` directo. Se cambió para que llame a
`patientsService.getById(patientId)` en su lugar — así `patients.service.js` sigue
siendo el único lugar que sabe cómo se guarda/valida un paciente.

## Por qué NO se adoptó (deliberado, no un olvido)

Evaluando la guía completa de "monolito modular" contra el tamaño real de este
proyecto (2 usuarios, 3 tablas, un solo desarrollador):

- **Sin contratos formales (OpenAPI/event schemas) entre módulos internos.** Tiene
  sentido cuando los módulos están en procesos o equipos distintos; acá son `require()`
  en el mismo proceso, sin nada que versionar entre ellos.
- **Sin CI/CD dedicado por módulo.** Hoy no hay CI configurado en absoluto — armar un
  pipeline por módulo para 3 módulos es infraestructura sin problema real que resuelva.
- **Sin estrategias de replicación de base de datos.** No aplica a una base con un
  puñado de filas.

Si el proyecto crece lo suficiente (más equipos, más módulos, necesidad real de
escalar partes por separado), estos son los primeros candidatos a reconsiderar — no
antes.

## Consecuencias

- Agregar un módulo nuevo (ej. citas) implica: su propia carpeta en `src/modules/`,
  su propio `service.js` dueño de sus tablas, y pedir prestado a otros módulos solo a
  través de sus funciones públicas de servicio.
- El límite se protege con un test automatizado (`test/module-boundaries.test.js`) que
  falla si alguna tabla queda referenciada desde el `service.js` de un módulo que no
  es su dueño — sin eso, la experiencia (documentada en la guía de este mismo patrón)
  es que los límites se erosionan solos con el tiempo.
