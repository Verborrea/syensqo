// Crea una cuenta de doctor. No existe un endpoint HTTP para esto a propósito
// — un doctor no debe poder autoprovisionarse una cuenta con acceso a datos
// de pacientes. Uso:
//   node db/create-doctor.js "Dra. Nombre Apellido" nombre@policlinico.pe "una contraseña larga"
require("dotenv").config();
const pool = require("../src/db");
const doctorsService = require("../src/modules/doctors/doctors.service");

async function main() {
  const [, , fullName, email, password] = process.argv;
  if (!fullName || !email || !password) {
    console.error('Uso: node db/create-doctor.js "Nombre completo" email@dominio.com "contraseña"');
    process.exit(1);
  }
  if (password.length < 8) {
    console.error("La contraseña debe tener al menos 8 caracteres.");
    process.exit(1);
  }

  try {
    const doctor = await doctorsService.createOrUpdate(fullName, email, password);
    console.log("Cuenta lista:", doctor);
  } finally {
    await pool.end();
  }
}

main().catch((err) => {
  console.error("Error:", err.message);
  process.exit(1);
});
