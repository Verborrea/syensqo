require("dotenv").config();
const fs = require("fs");
const path = require("path");
const { Pool } = require("pg");

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function migrate() {
  const sql = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
  await pool.query(sql);
  console.log("Migración aplicada correctamente.");
  await pool.end();
}

migrate().catch((err) => {
  console.error("Falló la migración:", err.message);
  process.exit(1);
});
