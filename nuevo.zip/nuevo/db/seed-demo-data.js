// Carga una cuenta de doctor y un set de datos de demostración (4 pacientes,
// 16 evaluaciones) enteramente sintéticos — pensado para instalaciones nuevas
// que quieren probar el flujo completo de la app sin depender de un dump con
// datos clínicos reales. No usar estos nombres/valores como si fueran de
// pacientes reales.
// Uso:
//   node db/seed-demo-data.js "Dra. Nombre Apellido" doctor@dominio.com "una contraseña larga"
require("dotenv").config();
const pool = require("../src/db");
const doctorsService = require("../src/modules/doctors/doctors.service");

const PATIENTS = [
  {
    full_name: "Carla Espinoza",
    birth_date: "1988-03-14",
    sex: "femenino",
    height_m: 1.58,
    evaluations: [
      { eval_date: "2026-02-10", peso_kg: 82.3, fm_pct: 38.2, smm_kg: 24.1, phase_angle: 5.9, tbw_pct: 46.5 },
      { eval_date: "2026-03-10", peso_kg: 80.1, fm_pct: 37.0, smm_kg: 24.3, phase_angle: 6.0, tbw_pct: 47.0 },
      { eval_date: "2026-04-10", peso_kg: 78.4, fm_pct: 35.9, smm_kg: 24.6, phase_angle: 6.1, tbw_pct: 47.6 },
      { eval_date: "2026-05-10", peso_kg: 76.9, fm_pct: 34.8, smm_kg: 24.9, phase_angle: 6.3, tbw_pct: 48.1 },
    ],
  },
  {
    full_name: "Jorge Huamán",
    birth_date: "1979-11-02",
    sex: "masculino",
    height_m: 1.72,
    evaluations: [
      { eval_date: "2026-02-15", peso_kg: 95.6, fm_pct: 29.4, smm_kg: 34.2, phase_angle: 6.5, tbw_pct: 52.3 },
      { eval_date: "2026-03-15", peso_kg: 93.2, fm_pct: 28.1, smm_kg: 34.6, phase_angle: 6.6, tbw_pct: 52.9 },
      { eval_date: "2026-04-15", peso_kg: 91.0, fm_pct: 27.0, smm_kg: 35.0, phase_angle: 6.8, tbw_pct: 53.4 },
      { eval_date: "2026-05-15", peso_kg: 89.1, fm_pct: 26.0, smm_kg: 35.3, phase_angle: 6.9, tbw_pct: 53.9 },
    ],
  },
  {
    full_name: "Rosa Quispe",
    birth_date: "1995-07-22",
    sex: "femenino",
    height_m: 1.61,
    evaluations: [
      { eval_date: "2026-02-20", peso_kg: 74.8, fm_pct: 40.5, smm_kg: 21.9, phase_angle: 5.2, tbw_pct: 44.0 },
      { eval_date: "2026-03-20", peso_kg: 73.0, fm_pct: 39.2, smm_kg: 22.1, phase_angle: 5.4, tbw_pct: 44.6 },
      { eval_date: "2026-04-20", peso_kg: 71.5, fm_pct: 38.0, smm_kg: 22.4, phase_angle: 5.5, tbw_pct: 45.1 },
      { eval_date: "2026-05-20", peso_kg: 70.2, fm_pct: 36.9, smm_kg: 22.7, phase_angle: 5.7, tbw_pct: 45.6 },
    ],
  },
  {
    full_name: "Miguel Ríos",
    birth_date: "1983-01-30",
    sex: "masculino",
    height_m: 1.75,
    evaluations: [
      { eval_date: "2026-02-25", peso_kg: 101.4, fm_pct: 32.8, smm_kg: 33.6, phase_angle: 6.0, tbw_pct: 50.1 },
      { eval_date: "2026-03-25", peso_kg: 98.7, fm_pct: 31.2, smm_kg: 34.0, phase_angle: 6.2, tbw_pct: 50.8 },
      { eval_date: "2026-04-25", peso_kg: 96.3, fm_pct: 29.9, smm_kg: 34.4, phase_angle: 6.4, tbw_pct: 51.4 },
      { eval_date: "2026-05-25", peso_kg: 94.2, fm_pct: 28.7, smm_kg: 34.8, phase_angle: 6.6, tbw_pct: 52.0 },
    ],
  },
];

async function main() {
  const [, , fullName, email, password] = process.argv;
  if (!fullName || !email || !password) {
    console.error('Uso: node db/seed-demo-data.js "Nombre completo" email@dominio.com "contraseña"');
    process.exit(1);
  }

  try {
    const { rows: existing } = await pool.query("SELECT count(*)::int AS n FROM patients");
    if (existing[0].n > 0) {
      console.error(`La tabla patients ya tiene ${existing[0].n} fila(s). No se vuelve a sembrar para no duplicar — si querés reiniciar, vaciá la base primero.`);
      process.exit(1);
    }

    const doctor = await doctorsService.createOrUpdate(fullName, email, password);
    console.log("Doctor listo:", doctor);

    for (const p of PATIENTS) {
      const { rows } = await pool.query(
        `INSERT INTO patients (full_name, birth_date, sex, height_m, created_by)
         VALUES ($1, $2, $3, $4, $5)
         RETURNING id`,
        [p.full_name, p.birth_date, p.sex, p.height_m, doctor.id]
      );
      const patientId = rows[0].id;

      for (const ev of p.evaluations) {
        await pool.query(
          `INSERT INTO evaluations
             (patient_id, eval_date, peso_kg, fm_pct, smm_kg, phase_angle, tbw_pct, is_manual, entered_by)
           VALUES ($1, $2, $3, $4, $5, $6, $7, true, $8)`,
          [patientId, ev.eval_date, ev.peso_kg, ev.fm_pct, ev.smm_kg, ev.phase_angle, ev.tbw_pct, doctor.id]
        );
      }
      console.log(`Paciente sembrado: ${p.full_name} (${p.evaluations.length} evaluaciones)`);
    }

    console.log("Seed completo: 1 doctor, 4 pacientes, 16 evaluaciones (todo sintético).");
  } finally {
    await pool.end();
  }
}

main().catch((err) => {
  console.error("Error:", err.message);
  process.exit(1);
});
