const { Pool, types } = require("pg");

// keep DATE columns (birth_date, eval_date) as plain 'YYYY-MM-DD' strings instead
// of letting node-postgres turn them into JS Date objects (which re-introduces
// timezone drift on the way back out as JSON).
types.setTypeParser(1082, (val) => val);

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Sin este listener, un error en un cliente inactivo del pool (conexión
// caída, red interrumpida, reinicio de Postgres) queda como excepción no
// capturada y tumba el proceso Node entero — confirmado reproduciéndolo
// contra baja_de_peso_test. Con el listener, el pool simplemente descarta
// ese cliente y sigue funcionando.
pool.on("error", (err) => {
  console.error("Error inesperado en un cliente inactivo del pool de Postgres:", err);
});

module.exports = pool;
