require("dotenv").config();
const app = require("./app");

const PORT = process.env.PORT || 3001;
const HOST = process.env.HOST || "127.0.0.1";
// bound to localhost only, on purpose: change HOST in .env (not here) when
// it's time to expose it to the policlínico's LAN.
app.listen(PORT, HOST, () => console.log(`API corriendo en http://${HOST}:${PORT}`));
