// Express app wiring, separated from src/server.js's app.listen() so tests can
// import this directly (via supertest) without binding a real network port.
const path = require("path");
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");

const authRouter = require("./modules/auth/auth.routes");
const patientsRouter = require("./modules/patients/patients.routes");
const { requireAuth } = require("./middleware/auth");

const app = express();

// CSP allows 'unsafe-inline' because the whole app is one self-contained HTML
// file with inline <style>/<script> — that's a deliberate tradeoff for this
// project's size, not an oversight. Everything else stays locked to 'self'.
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"]
    }
  }
}));

app.use(cors({ origin: process.env.ALLOWED_ORIGIN || true }));

// generous enough for real clinic use, tight enough to blunt brute-force/abuse
const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: true, legacyHeaders: false });
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });

app.use(express.json());

app.get("/api/health", (req, res) => res.json({ status: "ok" }));
app.use("/api/auth/login", loginLimiter);
app.use("/api/auth", apiLimiter, authRouter);
// evaluations va anidado dentro de patientsRouter (ver
// modules/patients/patients.routes.js) — un solo mount, apiLimiter y
// requireAuth corren una sola vez por request.
app.use("/api/patients", apiLimiter, requireAuth, patientsRouter);

app.use(express.static(path.join(__dirname, "..", "public")));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  // Errores de middleware como body-parser (payload > límite -> 413, JSON mal
  // formado -> 400) ya traen el status correcto en err.status/err.statusCode.
  // Antes esto se aplanaba siempre a 500, escondiéndole al cliente que el
  // problema era su request, no el servidor.
  const status = err.status || err.statusCode;
  if (status >= 400 && status < 500) {
    return res.status(status).json({ error: err.message || "Solicitud inválida" });
  }
  res.status(500).json({ error: "Error interno del servidor" });
});

module.exports = app;
