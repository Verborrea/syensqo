const authService = require("./auth.service");

async function login(req, res, next) {
  try {
    const { email, password } = req.body;
    const result = await authService.login(email, password);
    res.json(result);
  } catch (err) {
    next(err);
  }
}

async function me(req, res, next) {
  try {
    const doctor = await authService.me(req.doctor.id);
    res.json(doctor);
  } catch (err) {
    next(err);
  }
}

module.exports = { login, me };
