const express = require("express");
const { requireAuth } = require("../../middleware/auth");
const controller = require("./auth.controller");

const router = express.Router();

// No hay endpoint de registro público a propósito: un doctor no debe poder
// autoprovisionarse una cuenta. Las cuentas se crean con db/create-doctor.js
// (un script de línea de comandos que corre quien administra el sistema).
router.post("/login", controller.login);

router.get("/me", requireAuth, controller.me);

module.exports = router;
