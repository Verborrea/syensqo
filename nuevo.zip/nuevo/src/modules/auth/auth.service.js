const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const doctorsService = require("../doctors/doctors.service");
const { httpError } = require("../../lib/httpError");

async function login(email, password) {
  if (!email || !password) {
    throw httpError(400, "email y password son requeridos");
  }

  const doctor = await doctorsService.findByEmail(email);
  // misma respuesta exista o no el email, para no revelar qué correos están registrados
  if (!doctor) {
    throw httpError(401, "Credenciales inválidas");
  }
  const ok = await bcrypt.compare(password, doctor.password_hash);
  if (!ok) {
    throw httpError(401, "Credenciales inválidas");
  }

  const token = jwt.sign(
    { sub: doctor.id, email: doctor.email },
    process.env.JWT_SECRET,
    { expiresIn: "12h" }
  );
  return { token, doctor: { id: doctor.id, full_name: doctor.full_name, email: doctor.email } };
}

// para que el frontend pueda verificar si el token guardado sigue siendo válido
// al abrir la app, sin tener que adivinar a partir de un 401 en otra ruta.
async function me(doctorId) {
  const doctor = await doctorsService.findById(doctorId);
  if (!doctor) throw httpError(401, "No autenticado");
  return doctor;
}

module.exports = { login, me };
