const patientsService = require("./patients.service");

async function list(req, res, next) {
  try {
    res.json(await patientsService.listAll());
  } catch (err) {
    next(err);
  }
}

async function create(req, res, next) {
  try {
    const { full_name, birth_date, sex, height_m } = req.body;
    const patient = await patientsService.create({
      full_name,
      birth_date,
      sex,
      height_m,
      createdBy: req.doctor.id,
    });
    res.status(201).json(patient);
  } catch (err) {
    next(err);
  }
}

async function get(req, res, next) {
  try {
    res.json(await patientsService.getById(req.params.id));
  } catch (err) {
    next(err);
  }
}

module.exports = { list, create, get };
