const express = require("express");
const controller = require("./evaluations.controller");

// mergeParams para leer :patientId del path del router padre — este router
// se monta anidado dentro de patients.routes.js, nunca directo en app.js.
const router = express.Router({ mergeParams: true });

router.get("/", controller.list);
router.post("/", controller.create);

module.exports = router;
