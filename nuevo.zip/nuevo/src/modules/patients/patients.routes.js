const express = require("express");
const controller = require("./patients.controller");
const evaluationsRoutes = require("./evaluations.routes");

const router = express.Router();

router.get("/", controller.list);
router.post("/", controller.create);
router.get("/:id", controller.get);

// Anidado acá (no montado aparte en app.js) para que apiLimiter y requireAuth
// corran una sola vez por request. Antes /api/patients/:id/evaluations
// coincidía con dos mounts a la vez en app.js y consumía el rate limit
// compartido dos veces y verificaba el mismo JWT dos veces por request.
router.use("/:patientId/evaluations", evaluationsRoutes);

module.exports = router;
