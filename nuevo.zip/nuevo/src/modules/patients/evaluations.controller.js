const evaluationsService = require("./evaluations.service");

async function list(req, res, next) {
  try {
    res.json(await evaluationsService.list(req.params.patientId));
  } catch (err) {
    next(err);
  }
}

async function create(req, res, next) {
  try {
    const result = await evaluationsService.create(req.params.patientId, req.body, req.doctor.id);
    res.status(201).json(result);
  } catch (err) {
    next(err);
  }
}

module.exports = { list, create };
