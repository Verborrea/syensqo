const pool = require("../../db");
const { isUuid } = require("../../lib/validate");
const { httpError } = require("../../lib/httpError");

async function listAll() {
  const { rows } = await pool.query(
    "SELECT id, full_name, birth_date, sex, height_m, created_at FROM patients ORDER BY full_name"
  );
  return rows;
}

async function create({ full_name, birth_date, sex, height_m, createdBy }) {
  if (!full_name || !height_m) {
    throw httpError(400, "full_name y height_m son requeridos");
  }
  // mismos límites que el CHECK de la base (0.5 - 2.5 m, exclusivo) — validado
  // acá para que un valor fuera de rango dé un 400 claro, no un 500 de Postgres.
  const heightNum = Number(height_m);
  if (!Number.isFinite(heightNum) || heightNum <= 0.5 || heightNum >= 2.5) {
    throw httpError(400, "height_m debe ser un número entre 0.5 y 2.5");
  }
  const { rows } = await pool.query(
    `INSERT INTO patients (full_name, birth_date, sex, height_m, created_by)
     VALUES ($1, $2, $3, $4, $5) RETURNING *`,
    [full_name, birth_date || null, sex || null, height_m, createdBy]
  );
  return rows[0];
}

async function getById(id) {
  if (!isUuid(id)) {
    throw httpError(400, "id no es un identificador válido");
  }
  const { rows } = await pool.query("SELECT * FROM patients WHERE id = $1", [id]);
  if (!rows[0]) throw httpError(404, "Paciente no encontrado");
  return rows[0];
}

module.exports = { listAll, create, getById };
