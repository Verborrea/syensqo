const pool = require("../../db");
const { upsert } = require("../../lib/pgUpsert");
const { computeDerived } = require("../../lib/clinical");
const { isUuid, isInRange } = require("../../lib/validate");
const { httpError } = require("../../lib/httpError");
// El límite entre módulos importa: evaluations no consulta la tabla patients
// directo, le pide el dato a patients.service.js — así sigue siendo el único
// dueño de esa tabla, y si mañana cambia cómo se guarda/valida un paciente,
// solo hay un lugar que tocar.
const patientsService = require("./patients.service");

async function list(patientId) {
  if (!isUuid(patientId)) {
    throw httpError(400, "patientId no es un identificador válido");
  }
  const patient = await patientsService.getById(patientId);
  const heightM = Number(patient.height_m);
  const { rows } = await pool.query(
    "SELECT * FROM evaluations WHERE patient_id = $1 ORDER BY eval_date ASC",
    [patientId]
  );
  return rows.map((r) => computeDerived(r, heightM));
}

async function create(patientId, body, enteredBy) {
  if (!isUuid(patientId)) {
    throw httpError(400, "patientId no es un identificador válido");
  }

  const { eval_date, peso_kg, fm_pct, smm_kg, phase_angle, tbw_pct, percentile_phase } = body;

  const required = { eval_date, peso_kg, fm_pct, smm_kg, phase_angle, tbw_pct };
  for (const [key, value] of Object.entries(required)) {
    if (value === undefined || value === null || value === "") {
      throw httpError(400, `Falta el campo ${key}`);
    }
  }

  // mismos límites que los CHECK de la base — un valor fuera de rango debe
  // dar 400 acá, no un 500 cuando la base lo rechace. Los topes de peso_kg/
  // smm_kg/phase_angle espejan la precisión NUMERIC de cada columna
  // (peso_kg y smm_kg son NUMERIC(5,2) -> máx 999.99; phase_angle es
  // NUMERIC(3,1) -> máx 99.9) — antes solo se validaba "> 0", sin techo, y
  // un valor por encima del máximo representable llegaba a Postgres como un
  // "numeric field overflow" (22003) sin .status, cayendo a un 500 crudo.
  if (!isInRange(peso_kg, 0.01, 999.99)) throw httpError(400, "peso_kg debe ser un número entre 0.01 y 999.99");
  if (!isInRange(fm_pct, 0, 100)) throw httpError(400, "fm_pct debe ser un número entre 0 y 100");
  if (!isInRange(smm_kg, 0.01, 999.99)) throw httpError(400, "smm_kg debe ser un número entre 0.01 y 999.99");
  if (!isInRange(phase_angle, 0.1, 99.9)) throw httpError(400, "phase_angle debe ser un número entre 0.1 y 99.9");
  if (!isInRange(tbw_pct, 0, 100)) throw httpError(400, "tbw_pct debe ser un número entre 0 y 100");
  if (
    percentile_phase !== undefined &&
    percentile_phase !== null &&
    percentile_phase !== "" &&
    !isInRange(percentile_phase, 0, 100)
  ) {
    throw httpError(400, "percentile_phase debe ser un número entre 0 y 100");
  }

  const patient = await patientsService.getById(patientId);
  const heightM = Number(patient.height_m);

  const row = await upsert(pool, {
    updateText: `UPDATE evaluations SET
                   peso_kg = $1, fm_pct = $2, smm_kg = $3, phase_angle = $4,
                   tbw_pct = $5, percentile_phase = $6, entered_by = $7
                 WHERE patient_id = $8 AND eval_date = $9
                 RETURNING *`,
    updateValues: [peso_kg, fm_pct, smm_kg, phase_angle, tbw_pct, percentile_phase || null, enteredBy, patientId, eval_date],
    insertText: `INSERT INTO evaluations
       (patient_id, eval_date, peso_kg, fm_pct, smm_kg, phase_angle, tbw_pct, percentile_phase, is_manual, entered_by)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true, $9)
     RETURNING *`,
    insertValues: [patientId, eval_date, peso_kg, fm_pct, smm_kg, phase_angle, tbw_pct, percentile_phase || null, enteredBy],
  });

  return computeDerived(row, heightM);
}

module.exports = { list, create };
