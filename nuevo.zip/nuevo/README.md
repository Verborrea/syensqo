# Baja de Peso — backend

API para el panel de evolución del programa de Baja de Peso (Policlínico San Damián).
Node.js + Express + PostgreSQL, pensado para correr en el servidor propio del policlínico.

## Estado actual

- Base de datos `baja_de_peso` creada, con las tablas `doctors`, `patients`, `evaluations`.
- Usuario dedicado `baja_de_peso_app` (no usa el superusuario `postgres` para la app).
- Dashboard conectado a la API real — persistencia real, probado de punta a punta.
- **Login de doctores implementado** (email + contraseña, JWT, 12h de sesión). Todas las
  rutas de `/api/patients*` requieren estar autenticado.
- Seguridad: `helmet` (cabeceras), rate limiting, CORS restringido a un origen, servidor
  atado a `127.0.0.1` (no expuesto a la red todavía), sin vulnerabilidades XSS conocidas
  (el nombre del paciente se sanitiza antes de renderizarse).
- Probado con carga real: 100 conexiones concurrentes, lecturas y escrituras, sin errores
  ni corrupción de datos (ver sección de pruebas de carga más abajo).

## Requisitos (ya verificados en esta máquina)

- Node.js v22.16.0 ✓
- PostgreSQL 16.9, corriendo como servicio de Windows ✓

## Configuración

Las credenciales están en `.env` (no se sube a git):

```
DATABASE_URL=...
PORT=3001
HOST=127.0.0.1        # cambiar solo cuando haya que exponerlo a la red del policlínico
JWT_SECRET=...         # secreto largo y aleatorio, ya generado
ALLOWED_ORIGIN=http://127.0.0.1:3001
```

## Uso

```bash
npm install            # instalar dependencias
npm run db:migrate      # aplica db/schema.sql
npm start                 # levanta la API en http://127.0.0.1:3001
npm run dev                # igual, pero reinicia solo al guardar cambios
```

### Crear una cuenta de doctor

No hay registro público a propósito — un doctor no debe poder crearse su propia cuenta.
Las cuentas se crean por línea de comandos:

```bash
node db/create-doctor.js "Dra. Nombre Apellido" nombre@policlinico.pe "una contraseña larga"
```

## Endpoints disponibles

| Método | Ruta | Auth | Qué hace |
|---|---|---|---|
| GET | `/api/health` | No | chequeo de salud |
| POST | `/api/auth/login` | No | `{ email, password }` → `{ token, doctor }` |
| GET | `/api/auth/me` | Sí | devuelve el doctor del token actual |
| GET | `/api/patients` | Sí | lista pacientes |
| POST | `/api/patients` | Sí | crea paciente `{ full_name, birth_date, sex, height_m }` |
| GET | `/api/patients/:id` | Sí | detalle de un paciente |
| GET | `/api/patients/:id/evaluations` | Sí | evaluaciones con IMC/grasa/magra/estado calculados |
| POST | `/api/patients/:id/evaluations` | Sí | crea o actualiza (por fecha) una evaluación |

Las rutas con auth requieren `Authorization: Bearer <token>`.

### Modelo de acceso entre doctores

Cualquier doctor autenticado puede leer y editar **cualquier** paciente — no hay ningún
filtro por `created_by`/`entered_by` en las queries. Es intencional, no un descuido:
el consultorio usa un roster compartido (administrador + doctores viendo a los mismos
pacientes), confirmado explícitamente el 2026-08-07. Si en algún momento se suma un
doctor cuyos pacientes no deban cruzarse con los de otro, este es el punto exacto a
tocar: las queries de `src/modules/patients/patients.service.js` y
`evaluations.service.js`.

## Pruebas de carga (100 usuarios concurrentes)

Corridas con `autocannon` contra esta misma app:

| Escenario | Resultado |
|---|---|
| 100 conexiones, lectura de pacientes | ~4,400 req/seg, latencia mediana 21ms, 0 errores |
| 100 conexiones, lectura de evaluaciones (ruta más pesada) | ~2,900 req/seg, latencia mediana 33ms, 0 errores |
| 100 conexiones, escritura concurrente sobre la misma fila | ~2,775 req/seg, latencia mediana 34ms, 0 errores, 0 duplicados |

Repetir con: `npx autocannon -c 100 -d 15 http://127.0.0.1:3001/api/patients` (agregar
`-H "Authorization: Bearer <token>"` ahora que las rutas requieren login).

## ⚠️ Importante: contraseña del superusuario `postgres`

Está en `123456` — es débil, y esta base va a contener datos de salud de pacientes reales
más adelante. Recomiendo cambiarla pronto:

```powershell
$env:PGPASSWORD = "123456"
psql -U postgres -h localhost -c "ALTER USER postgres WITH PASSWORD 'una_contraseña_larga_y_unica';"
```

(Esto no toca `pg_hba.conf` ni reinicia el servicio — es solo cambiar la contraseña sabiendo
la actual, así que lo puedes correr tú mismo sin pasos adicionales.)

## Tests

67 pruebas automatizadas (unitarias + integración), corren contra una base de datos
**separada** (`baja_de_peso_test`), nunca contra la real:

```bash
npm test
```

Cobertura actual: lógica clínica pura del backend (`classify`, `computeDerived`), el
middleware de autenticación, las rutas de `/api/auth` y `/api/patients*` de punta a punta
(validación, 401/404/413, upsert y escrituras concurrentes), simulación de ataques
comunes (SQLi, JWT forjado, mass assignment, prototype pollution), el script
`db/create-doctor.js`, un test de "fitness arquitectónica" que falla si algún módulo
consulta una tabla que no le pertenece (ver `docs/ADR-001-monolito-modular.md`), y la
lógica pura de `public/index.html` (clasificación, alertas clínicas, puntaje del radar) —
cargada con `jsdom` desde el archivo real, sin fixture aparte, vía
`window.__BDP_TESTABLES__` (ver el comentario al final del `<script>` del archivo).

**Pendiente, sin infraestructura de test todavía:** la lógica de `public/index.html`
(alertas clínicas, radar de perfil) no tiene cobertura — el archivo no se puede requerir
desde Node (usa `document`/`fetch`/`sessionStorage`), así que testearlo a fondo requiere
elegir una estrategia (jsdom, Playwright, o extraer la lógica compartida a un módulo
común) antes de escribir el primer test.

## Próximos pasos

1. Vista de lista/búsqueda de pacientes (hoy el selector es un dropdown simple).
2. `updated_at` en las tablas + índices en `patients.created_by` / `evaluations.entered_by`.
3. Logging de acceso / auditoría (quién vio o modificó qué, y cuándo).
4. Backups de la base de datos.
5. Definir cómo se ejecuta esto como servicio permanente en el servidor (por ejemplo con
   `pm2` o como servicio de Windows), en vez de dejarlo corriendo en una terminal.
6. Cuando llegue el momento de exponerlo a la red del policlínico: cambiar `HOST` en `.env`,
   revisar la regla de firewall de Windows para Node.js (hoy permite el perfil "Público").
