// Test de "fitness arquitectónica" (ver docs/ADR-001-monolito-modular.md): un
// módulo no debería consultar directamente una tabla que no le pertenece.
// Sin esto, la experiencia documentada en la guía de monolito modular es que
// estos límites se erosionan solos con el tiempo — nadie lo nota hasta que ya
// está mezclado. Chequeo estático simple (lee el código fuente, no requiere
// dependencias nuevas ni un linter dedicado) — proporcional al tamaño real de
// este proyecto, no un pipeline de CI por módulo.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const path = require("path");

// service.js -> tablas que le pertenecen. Si un service.js no está listado
// acá, se asume que no debería tocar ninguna tabla directo (ej. auth, que
// delega todo a doctorsService).
const OWNERSHIP = {
  "src/modules/patients/patients.service.js": ["patients"],
  "src/modules/patients/evaluations.service.js": ["evaluations"],
  "src/modules/doctors/doctors.service.js": ["doctors"],
  "src/modules/auth/auth.service.js": [],
};

const ALL_TABLES = ["patients", "evaluations", "doctors"];
const TABLE_REF_RE = /\b(?:FROM|INTO|UPDATE|JOIN)\s+([a-z_]+)/gi;

function referencedTables(source) {
  const found = new Set();
  let m;
  while ((m = TABLE_REF_RE.exec(source))) {
    const table = m[1].toLowerCase();
    if (ALL_TABLES.includes(table)) found.add(table);
  }
  return found;
}

for (const [relPath, ownedTables] of Object.entries(OWNERSHIP)) {
  test(`límite de módulo: ${relPath} solo consulta sus propias tablas (${ownedTables.join(", ") || "ninguna"})`, () => {
    const fullPath = path.join(__dirname, "..", relPath);
    const source = fs.readFileSync(fullPath, "utf8");
    const referenced = referencedTables(source);
    const forbidden = [...referenced].filter((t) => !ownedTables.includes(t));
    assert.deepEqual(
      forbidden,
      [],
      `${relPath} consulta tabla(s) que no le pertenecen: ${forbidden.join(", ")} — ` +
        "debería pedírselo al service.js dueño de esa tabla en vez de consultarla directo"
    );
  });
}
