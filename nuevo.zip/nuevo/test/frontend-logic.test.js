// Pruebas de la lógica pura de public/index.html (T-08 de la auditoría). Carga
// el archivo REAL con jsdom (no una copia/fixture aparte) y ejecuta su
// <script> tal cual corre en el navegador, para no probar algo que diverja
// del archivo real. Solo se testea la lógica de cálculo expuesta en
// window.__BDP_TESTABLES__ (ver el comentario en index.html) — nada de
// renderizado/DOM, eso queda fuera de alcance a propósito (ver la
// conversación sobre por qué un E2E con navegador real es una decisión de
// infraestructura aparte).
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const path = require("path");
const { JSDOM } = require("jsdom");

const html = fs.readFileSync(path.join(__dirname, "..", "public", "index.html"), "utf8");

function loadApp() {
  const dom = new JSDOM(html, { runScripts: "dangerously", url: "http://localhost/" });
  return dom.window.__BDP_TESTABLES__;
}

// ---------- classify / computeDerived ----------

test("frontend classify(): mismos límites clínicos que el backend (18.5/25/30)", () => {
  const { classify } = loadApp();
  assert.equal(classify(18.49).key, "bajo");
  assert.equal(classify(18.5).key, "normal");
  assert.equal(classify(24.99).key, "normal");
  assert.equal(classify(25).key, "sobrepeso");
  assert.equal(classify(29.99).key, "sobrepeso");
  assert.equal(classify(30).key, "obesidad");
});

test("frontend computeDerived(): coincide con el informe real de Maxidat (Gianella, 15.05.2026) — mismo caso que el backend", () => {
  const { computeDerived, setHeight } = loadApp();
  setHeight(1.6);
  const v = { peso: 76.4, fmPct: 41.4 };
  computeDerived(v); // muta v en lugar de retornar — estilo del frontend, distinto al backend
  assert.ok(Math.abs(v.imc - 29.84) < 0.01, `imc esperado ~29.84, dio ${v.imc}`);
  assert.ok(Math.abs(v.fmKg - 31.6) < 0.05, `fmKg esperado ~31.6, dio ${v.fmKg}`);
  assert.ok(Math.abs(v.ffmKg - 44.8) < 0.05, `ffmKg esperado ~44.8, dio ${v.ffmKg}`);
  assert.equal(v.status.key, "sobrepeso");
});

// ---------- windowVisits ----------

test("frontend windowVisits(): filtra hacia atrás desde la fecha de referencia, igual que el backend", () => {
  const { windowVisits, setVisits } = loadApp();
  setVisits([{ date: "2025-12-15" }, { date: "2026-03-15" }, { date: "2026-05-15" }]);
  const win = windowVisits(3, "2026-05-15");
  assert.deepEqual(win.map((v) => v.date), ["2026-03-15", "2026-05-15"]);
});

// ---------- computeAlerts ----------

function makeVisit(raw, testables) {
  const v = Object.assign({}, raw);
  testables.computeDerived(v);
  return v;
}

test("frontend computeAlerts(): secuencia con pérdida muscular, dos cambios de categoría, y cruce a bajo peso", () => {
  const testables = loadApp();
  testables.setHeight(1.65); // HEIGHT2 = 2.7225

  const visits = [
    makeVisit({ date: "2026-01-01", label: "Ene 2026", peso: 85, fmPct: 35, smm: 25, phase: 5.0, tbwPct: 45, tbwL: 38.25 }, testables),
    makeVisit({ date: "2026-02-01", label: "Feb 2026", peso: 75, fmPct: 32, smm: 24, phase: 5.1, tbwPct: 44, tbwL: 33 }, testables), // smm baja 25->24
    makeVisit({ date: "2026-03-01", label: "Mar 2026", peso: 65, fmPct: 28, smm: 25, phase: 5.3, tbwPct: 44.5, tbwL: 28.9 }, testables),
    makeVisit({ date: "2026-04-01", label: "Abr 2026", peso: 48, fmPct: 20, smm: 26, phase: 5.5, tbwPct: 45, tbwL: 21.6 }, testables),
  ];

  // confirma las categorías esperadas antes de testear las alertas que dependen de ellas
  assert.equal(visits[0].status.key, "obesidad");
  assert.equal(visits[1].status.key, "sobrepeso");
  assert.equal(visits[2].status.key, "normal");
  assert.equal(visits[3].status.key, "bajo");

  testables.setVisits(visits);
  const alerts = testables.computeAlerts();
  const titles = alerts.map((a) => a.title);

  assert.equal(alerts.length, 6, `se esperaban 6 alertas, dio ${alerts.length}: ${titles.join(" | ")}`);
  assert.ok(titles.includes("Posible estancamiento / pérdida muscular"));
  assert.ok(titles.includes("Cambio de categoría de IMC: de Obesidad a Sobrepeso"));
  assert.ok(titles.includes("Cambio de categoría de IMC: de Sobrepeso a Normal"));
  assert.ok(titles.includes("Cruzó a bajo peso — riesgo de desnutrición"));
  assert.ok(titles.includes("Composición del descenso: pérdida de grasa, no de músculo"));
  assert.ok(titles.includes("Paciente actualmente en bajo peso"));
  assert.ok(!titles.includes("Recuperación nutricional en curso"), "no debería disparar recuperación cuando el peso sigue bajando");
});

test("frontend computeAlerts(): descenso saludable (grasa baja, músculo estable) — patrón deseable, sin alertas de más", () => {
  const testables = loadApp();
  testables.setHeight(1.75); // HEIGHT2 = 3.0625

  const visits = [
    makeVisit({ date: "2026-01-01", label: "Ene 2026", peso: 90, fmPct: 30, smm: 30, phase: 5.0, tbwPct: 50, tbwL: 45 }, testables),
    makeVisit({ date: "2026-02-01", label: "Feb 2026", peso: 86, fmPct: 27, smm: 30, phase: 5.1, tbwPct: 50, tbwL: 43 }, testables),
  ];
  testables.setVisits(visits);
  const alerts = testables.computeAlerts();
  const titles = alerts.map((a) => a.title);

  // no usar assert.deepEqual acá: las strings vienen del realm separado que
  // crea jsdom al ejecutar el <script> de index.html, y deepEqual las
  // reporta como "no reference-equal" aunque === confirma que son idénticas
  // — es una rareza de comparar valores cross-realm con esa función, no un
  // bug de la app (verificado: titles[0] === expected da true).
  assert.equal(titles.length, 1, `se esperaba 1 alerta, dio ${titles.length}: ${titles.join(" | ")}`);
  assert.ok(titles.includes("Composición del descenso: pérdida de grasa, no de músculo"));
});

// ---------- RADAR_AXES ----------

test("frontend RADAR_AXES: el eje de IMC puntúa 100 exactamente en el óptimo (21.7) y baja al alejarse", () => {
  const { RADAR_AXES } = loadApp();
  const imcAxis = RADAR_AXES.find((ax) => ax.label === "IMC (salud)");
  assert.equal(imcAxis.score({ imc: 21.7 }), 100);
  assert.equal(imcAxis.score({ imc: 21.7 + 5 }), 80); // 100 - 5*4
  assert.equal(imcAxis.score({ imc: 21.7 + 25 }), 0); // clamp a 0, no negativo
});

// "Progreso de pérdida" se sacó a propósito (pentágono, no hexágono, ver la
// conversación) — era el único eje que comparaba al paciente contra su propio
// historial en vez de un rango clínico/poblacional como los otros 5.
test("frontend RADAR_AXES: son 5 ejes (pentágono), sin 'Progreso de pérdida'", () => {
  const { RADAR_AXES } = loadApp();
  assert.equal(RADAR_AXES.length, 5, "el radar debería tener exactamente 5 ejes");
  assert.ok(
    !RADAR_AXES.some((ax) => ax.label === "Progreso de pérdida"),
    "'Progreso de pérdida' no debería estar — se sacó a propósito"
  );
  // no usar assert.deepEqual acá: las strings vienen del realm que crea
  // jsdom, y deepEqual las reporta como "no reference-equal" aunque el
  // contenido sea idéntico (misma rareza que ya documentamos antes).
  const labels = RADAR_AXES.map((ax) => ax.label);
  const expected = ["IMC (salud)", "% Grasa", "Músculo (SMM)", "Ángulo de fase", "Agua corporal"];
  expected.forEach((label, i) => assert.equal(labels[i], label, `eje #${i} debería ser "${label}"`));
});
