// Pruebas de integración de /api/patients* contra baja_de_peso_test.
require("dotenv").config({ path: ".env.test" });
const test = require("node:test");
const assert = require("node:assert/strict");
const request = require("supertest");
const bcrypt = require("bcryptjs");

const pool = require("../src/db");
const app = require("../src/app");

let token;
let patientId;

test.before(async () => {
  await pool.query("TRUNCATE TABLE doctors, patients, evaluations CASCADE");
  const hash = await bcrypt.hash("ClaveDePrueba123", 4);
  await pool.query(
    "INSERT INTO doctors (full_name, email, password_hash) VALUES ('Dra. Test', 'doctora@test.com', $1)",
    [hash]
  );
  const login = await request(app).post("/api/auth/login").send({ email: "doctora@test.com", password: "ClaveDePrueba123" });
  token = login.body.token;
});

test.after(async () => {
  await pool.end();
});

test("GET /api/patients sin token: 401", async () => {
  const res = await request(app).get("/api/patients");
  assert.equal(res.status, 401);
});

test("POST /api/patients sin full_name: 400", async () => {
  const res = await request(app).post("/api/patients").set("Authorization", "Bearer " + token).send({ height_m: 1.6 });
  assert.equal(res.status, 400);
});

test("POST /api/patients sin height_m: 400", async () => {
  const res = await request(app).post("/api/patients").set("Authorization", "Bearer " + token).send({ full_name: "Paciente Test" });
  assert.equal(res.status, 400);
});

test("POST /api/patients: crea el paciente y lo atribuye al doctor autenticado", async () => {
  const res = await request(app)
    .post("/api/patients")
    .set("Authorization", "Bearer " + token)
    .send({ full_name: "Paciente Test", height_m: 1.65, sex: "femenino", birth_date: "1995-01-01" });
  assert.equal(res.status, 201);
  assert.ok(res.body.id);
  patientId = res.body.id;

  const { rows } = await pool.query("SELECT created_by FROM patients WHERE id = $1", [patientId]);
  assert.ok(rows[0].created_by, "created_by no debería quedar null");
});

test("GET /api/patients con token válido: 200 y devuelve la lista con el paciente creado", async () => {
  const res = await request(app).get("/api/patients").set("Authorization", "Bearer " + token);
  assert.equal(res.status, 200);
  assert.ok(Array.isArray(res.body));
  assert.ok(res.body.some((p) => p.id === patientId), "el paciente creado debería aparecer en la lista");
});

test("GET /api/patients/:id con id existente: 200 y devuelve el paciente completo", async () => {
  const res = await request(app).get(`/api/patients/${patientId}`).set("Authorization", "Bearer " + token);
  assert.equal(res.status, 200);
  assert.equal(res.body.id, patientId);
  assert.equal(res.body.full_name, "Paciente Test");
});

test("GET /api/patients/:id con id inexistente (pero UUID válido): 404", async () => {
  const res = await request(app)
    .get("/api/patients/00000000-0000-0000-0000-000000000000")
    .set("Authorization", "Bearer " + token);
  assert.equal(res.status, 404);
});

test("GET /api/patients/:id con id mal formado (no UUID): 400", async () => {
  const res = await request(app).get("/api/patients/no-soy-un-uuid").set("Authorization", "Bearer " + token);
  assert.equal(res.status, 400);
});

test("POST /api/patients/:id/evaluations: falta un campo requerido -> 400", async () => {
  const res = await request(app)
    .post(`/api/patients/${patientId}/evaluations`)
    .set("Authorization", "Bearer " + token)
    .send({ eval_date: "2026-01-01", peso_kg: 70, fm_pct: 30, smm_kg: 20, phase_angle: 5 }); // sin tbw_pct
  assert.equal(res.status, 400);
});

test("POST /api/patients/:id/evaluations sobre paciente inexistente: 404", async () => {
  const res = await request(app)
    .post("/api/patients/00000000-0000-0000-0000-000000000000/evaluations")
    .set("Authorization", "Bearer " + token)
    .send({ eval_date: "2026-01-01", peso_kg: 70, fm_pct: 30, smm_kg: 20, phase_angle: 5, tbw_pct: 40 });
  assert.equal(res.status, 404);
});

test("POST /api/patients/:id/evaluations: crea la evaluación con IMC calculado correctamente", async () => {
  const res = await request(app)
    .post(`/api/patients/${patientId}/evaluations`)
    .set("Authorization", "Bearer " + token)
    .send({ eval_date: "2026-01-01", peso_kg: 70, fm_pct: 30, smm_kg: 20, phase_angle: 5, tbw_pct: 45 });
  assert.equal(res.status, 201);
  const expectedImc = 70 / (1.65 * 1.65);
  assert.ok(Math.abs(res.body.imc - expectedImc) < 0.01);
});

test("POST /api/patients/:id/evaluations: misma fecha actualiza en vez de duplicar (upsert)", async () => {
  const first = await request(app)
    .post(`/api/patients/${patientId}/evaluations`)
    .set("Authorization", "Bearer " + token)
    .send({ eval_date: "2026-02-01", peso_kg: 68, fm_pct: 29, smm_kg: 21, phase_angle: 5.2, tbw_pct: 44 });
  assert.equal(first.status, 201);

  const second = await request(app)
    .post(`/api/patients/${patientId}/evaluations`)
    .set("Authorization", "Bearer " + token)
    .send({ eval_date: "2026-02-01", peso_kg: 67, fm_pct: 28, smm_kg: 21.5, phase_angle: 5.3, tbw_pct: 44.2 });
  assert.equal(second.status, 201);

  const { rows } = await pool.query(
    "SELECT peso_kg FROM evaluations WHERE patient_id = $1 AND eval_date = '2026-02-01'",
    [patientId]
  );
  assert.equal(rows.length, 1, "no debería haber quedado una fila duplicada");
  assert.equal(Number(rows[0].peso_kg), 67, "debería tener el valor de la segunda escritura, no la primera");
});

// HALLAZGO de la auditoría (T-06): el upsert ya se había probado con carga
// manual (autocannon, sesión anterior: 100 conexiones concurrentes sobre la
// misma fila, 0 duplicados) pero esa prueba nunca quedó como test
// automatizado. Esto reproduce lo mismo con Promise.all, preservado en la
// suite — si alguien reescribe el upsert como SELECT + INSERT/UPDATE
// condicional (rompiendo la atomicidad), esto lo agarra.
test("POST /api/patients/:id/evaluations: escrituras concurrentes sobre la misma fecha no duplican la fila", async () => {
  const [a, b] = await Promise.all([
    request(app)
      .post(`/api/patients/${patientId}/evaluations`)
      .set("Authorization", "Bearer " + token)
      .send({ eval_date: "2026-05-01", peso_kg: 60, fm_pct: 25, smm_kg: 20, phase_angle: 5, tbw_pct: 40 }),
    request(app)
      .post(`/api/patients/${patientId}/evaluations`)
      .set("Authorization", "Bearer " + token)
      .send({ eval_date: "2026-05-01", peso_kg: 61, fm_pct: 26, smm_kg: 21, phase_angle: 5.1, tbw_pct: 41 }),
  ]);
  assert.equal(a.status, 201);
  assert.equal(b.status, 201);

  const { rows } = await pool.query(
    "SELECT peso_kg FROM evaluations WHERE patient_id = $1 AND eval_date = '2026-05-01'",
    [patientId]
  );
  assert.equal(rows.length, 1, "no debería haber quedado una fila duplicada bajo escritura concurrente");
  assert.ok([60, 61].includes(Number(rows[0].peso_kg)), "debería tener el valor de una de las dos escrituras (la que ganó la carrera)");
});

test("GET /api/patients/:id/evaluations: devuelve ordenado por fecha", async () => {
  const res = await request(app)
    .get(`/api/patients/${patientId}/evaluations`)
    .set("Authorization", "Bearer " + token);
  assert.equal(res.status, 200);
  assert.ok(res.body.length >= 2);
  const dates = res.body.map((e) => e.eval_date);
  const sorted = [...dates].sort();
  assert.deepEqual(dates, sorted);
});

test("POST /api/patients/:id/evaluations: peso_kg negativo: 400", async () => {
  const res = await request(app)
    .post(`/api/patients/${patientId}/evaluations`)
    .set("Authorization", "Bearer " + token)
    .send({ eval_date: "2026-03-01", peso_kg: -5, fm_pct: 30, smm_kg: 20, phase_angle: 5, tbw_pct: 40 });
  assert.equal(res.status, 400);
});

test("POST /api/patients/:id/evaluations: fm_pct fuera de rango (>100): 400", async () => {
  const res = await request(app)
    .post(`/api/patients/${patientId}/evaluations`)
    .set("Authorization", "Bearer " + token)
    .send({ eval_date: "2026-03-02", peso_kg: 70, fm_pct: 150, smm_kg: 20, phase_angle: 5, tbw_pct: 40 });
  assert.equal(res.status, 400);
});

test("POST /api/patients/:id/evaluations con patientId mal formado (no UUID): 400", async () => {
  const res = await request(app)
    .post("/api/patients/no-soy-un-uuid/evaluations")
    .set("Authorization", "Bearer " + token)
    .send({ eval_date: "2026-03-01", peso_kg: 70, fm_pct: 30, smm_kg: 20, phase_angle: 5, tbw_pct: 40 });
  assert.equal(res.status, 400);
});

test("GET /api/patients/:id/evaluations con patientId mal formado (no UUID): 400", async () => {
  const res = await request(app)
    .get("/api/patients/no-soy-un-uuid/evaluations")
    .set("Authorization", "Bearer " + token);
  assert.equal(res.status, 400);
});

test("POST /api/patients sin height_m en rango válido (fuera del CHECK): 400", async () => {
  const res = await request(app)
    .post("/api/patients")
    .set("Authorization", "Bearer " + token)
    .send({ full_name: "Paciente Altura Inválida", height_m: 3.5 });
  assert.equal(res.status, 400);
});

test("POST /api/patients con height_m exactamente en el límite (0.5 y 2.5, exclusivo): 400", async () => {
  const low = await request(app).post("/api/patients").set("Authorization", "Bearer " + token).send({ full_name: "Límite 0.5", height_m: 0.5 });
  assert.equal(low.status, 400);
  const high = await request(app).post("/api/patients").set("Authorization", "Bearer " + token).send({ full_name: "Límite 2.5", height_m: 2.5 });
  assert.equal(high.status, 400);
});

// HALLAZGO de la auditoría (H-02), corregido: peso_kg/smm_kg/phase_angle no
// tenían techo — solo se validaba "> 0" — así que un valor por encima de lo
// que la columna NUMERIC puede representar llegaba a Postgres y volvía como
// un 500 crudo ("numeric field overflow") en vez de un 400 claro.
test("POST /api/patients/:id/evaluations: peso_kg fuera del máximo representable (NUMERIC(5,2)): 400", async () => {
  const res = await request(app)
    .post(`/api/patients/${patientId}/evaluations`)
    .set("Authorization", "Bearer " + token)
    .send({ eval_date: "2026-04-01", peso_kg: 99999, fm_pct: 30, smm_kg: 20, phase_angle: 5, tbw_pct: 40 });
  assert.equal(res.status, 400);
});

test("POST /api/patients/:id/evaluations: smm_kg fuera del máximo representable (NUMERIC(5,2)): 400", async () => {
  const res = await request(app)
    .post(`/api/patients/${patientId}/evaluations`)
    .set("Authorization", "Bearer " + token)
    .send({ eval_date: "2026-04-02", peso_kg: 70, fm_pct: 30, smm_kg: 99999, phase_angle: 5, tbw_pct: 40 });
  assert.equal(res.status, 400);
});

test("POST /api/patients/:id/evaluations: phase_angle fuera del máximo representable (NUMERIC(3,1)): 400", async () => {
  const res = await request(app)
    .post(`/api/patients/${patientId}/evaluations`)
    .set("Authorization", "Bearer " + token)
    .send({ eval_date: "2026-04-03", peso_kg: 70, fm_pct: 30, smm_kg: 20, phase_angle: 500, tbw_pct: 40 });
  assert.equal(res.status, 400);
});

test("POST /api/patients/:id/evaluations: fm_pct y tbw_pct exactamente en 0 y 100 (inclusivo): 201", async () => {
  const res = await request(app)
    .post(`/api/patients/${patientId}/evaluations`)
    .set("Authorization", "Bearer " + token)
    .send({ eval_date: "2026-04-04", peso_kg: 70, fm_pct: 0, smm_kg: 20, phase_angle: 5, tbw_pct: 100 });
  assert.equal(res.status, 201);
  assert.equal(res.body.fm_pct, 0);
  assert.equal(res.body.tbw_pct, 100);
});
