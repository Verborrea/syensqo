// Pruebas unitarias puras — sin base de datos, sin red. Cubren la lógica
// clínica compartida (src/lib/clinical.js), que es la misma que usa el
// dashboard para clasificar pacientes.
const test = require("node:test");
const assert = require("node:assert/strict");
const { classify, computeDerived } = require("../src/lib/clinical");

test("classify: límite bajo peso / normal en 18.5", () => {
  assert.equal(classify(18.49).key, "bajo");
  assert.equal(classify(18.5).key, "normal");
});

test("classify: límite normal / sobrepeso en 25", () => {
  assert.equal(classify(24.99).key, "normal");
  assert.equal(classify(25).key, "sobrepeso");
});

test("classify: límite sobrepeso / obesidad en 30", () => {
  assert.equal(classify(29.99).key, "sobrepeso");
  assert.equal(classify(30).key, "obesidad");
});

test("classify: valores extremos no revientan (desnutrición severa y obesidad grave)", () => {
  assert.equal(classify(10).key, "bajo");
  assert.equal(classify(60).key, "obesidad");
});

test("computeDerived: coincide con el informe real de Maxidat (Gianella, 15.05.2026)", () => {
  const r = computeDerived(
    { peso_kg: 76.4, fm_pct: 41.4, smm_kg: 20.16, phase_angle: 5.6, tbw_pct: 42.8 },
    1.60
  );
  assert.ok(Math.abs(r.imc - 29.84) < 0.01, `imc esperado ~29.84, dio ${r.imc}`);
  assert.ok(Math.abs(r.fm_kg - 31.6) < 0.05, `fm_kg esperado ~31.6, dio ${r.fm_kg}`);
  assert.ok(Math.abs(r.ffm_kg - 44.8) < 0.05, `ffm_kg esperado ~44.8, dio ${r.ffm_kg}`);
  assert.equal(r.status.key, "sobrepeso");
});

// HALLAZGO de la auditoría (H-06): classify()/computeDerived() están
// duplicados a mano en public/index.html (líneas ~675-701), sin ningún
// mecanismo que los mantenga sincronizados. No se puede requerir ese archivo
// desde Node (usa document/fetch/sessionStorage — ver la conversación sobre
// por qué testear el frontend necesita su propia decisión de
// infraestructura), así que esto codifica a mano el resultado de la MISMA
// fórmula tal como está escrita HOY en el frontend. Si alguien cambia un
// umbral clínico en un solo lado, este test se rompe.
test("computeDerived: coincide con la fórmula duplicada en public/index.html (guarda contra que diverjan)", () => {
  const r = computeDerived({ peso_kg: 88, fm_pct: 25.5, smm_kg: 30, phase_angle: 5, tbw_pct: 45 }, 1.75);
  assert.ok(Math.abs(r.imc - 28.734693877551) < 1e-9, `imc esperado ~28.7347, dio ${r.imc}`);
  assert.equal(r.fm_kg, 22.44);
  assert.equal(r.ffm_kg, 65.56);
  assert.equal(r.status.key, "sobrepeso");
});

test("computeDerived: masa grasa + masa magra siempre suman el peso total", () => {
  const r = computeDerived({ peso_kg: 90, fm_pct: 33.3, smm_kg: 25, phase_angle: 5, tbw_pct: 45 }, 1.75);
  assert.ok(Math.abs(r.fm_kg + r.ffm_kg - 90) < 0.01);
});

test("computeDerived: convierte a número aunque Postgres devuelva NUMERIC como string", () => {
  const r = computeDerived(
    { peso_kg: "80.5", fm_pct: "40", smm_kg: "20", phase_angle: "5", tbw_pct: "42" },
    1.6
  );
  assert.equal(typeof r.imc, "number");
  assert.equal(typeof r.peso_kg, "number");
  assert.ok(!Number.isNaN(r.imc));
});
