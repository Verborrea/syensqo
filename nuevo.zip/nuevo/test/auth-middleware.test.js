// Pruebas unitarias del middleware de autenticación — con req/res simulados,
// sin servidor HTTP real ni base de datos.
const test = require("node:test");
const assert = require("node:assert/strict");

process.env.JWT_SECRET = "unit-test-secret-not-for-production";
const jwt = require("jsonwebtoken");
const { requireAuth } = require("../src/middleware/auth");

function mockRes() {
  const res = { statusCode: null, body: null };
  res.status = function (code) { res.statusCode = code; return res; };
  res.json = function (body) { res.body = body; return res; };
  return res;
}

test("requireAuth: rechaza si no hay header Authorization", () => {
  const res = mockRes();
  let nextCalled = false;
  requireAuth({ headers: {} }, res, () => { nextCalled = true; });
  assert.equal(res.statusCode, 401);
  assert.equal(nextCalled, false);
});

test("requireAuth: rechaza un esquema distinto de Bearer", () => {
  const res = mockRes();
  requireAuth({ headers: { authorization: "Basic abc123" } }, res, () => {});
  assert.equal(res.statusCode, 401);
});

test("requireAuth: rechaza un token corrupto/no-JWT", () => {
  const res = mockRes();
  requireAuth({ headers: { authorization: "Bearer esto-no-es-un-jwt" } }, res, () => {});
  assert.equal(res.statusCode, 401);
});

test("requireAuth: rechaza un token firmado con otro secreto", () => {
  const badToken = jwt.sign({ sub: "x" }, "un-secreto-distinto-al-real");
  const res = mockRes();
  requireAuth({ headers: { authorization: "Bearer " + badToken } }, res, () => {});
  assert.equal(res.statusCode, 401);
});

test("requireAuth: rechaza un token expirado", () => {
  const expired = jwt.sign({ sub: "x", email: "a@b.com" }, process.env.JWT_SECRET, { expiresIn: -10 });
  const res = mockRes();
  requireAuth({ headers: { authorization: "Bearer " + expired } }, res, () => {});
  assert.equal(res.statusCode, 401);
});

test("requireAuth: acepta un token válido y adjunta req.doctor", () => {
  const token = jwt.sign({ sub: "doc-123", email: "a@b.com" }, process.env.JWT_SECRET);
  const req = { headers: { authorization: "Bearer " + token } };
  const res = mockRes();
  let nextCalled = false;
  requireAuth(req, res, () => { nextCalled = true; });
  assert.equal(nextCalled, true);
  assert.equal(res.statusCode, null, "no debería haber tocado la respuesta");
  assert.deepEqual(req.doctor, { id: "doc-123", email: "a@b.com" });
});
