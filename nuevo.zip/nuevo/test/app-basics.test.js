// Gaps de cobertura encontrados en la revisión pre-migración del 2026-08-07:
// /api/health, las cabeceras de helmet, el servido de archivos estáticos, y
// el loginLimiter (20/15min) nunca tuvieron un test propio — se probaban solo
// indirectamente o no se probaban en absoluto.
require("dotenv").config({ path: ".env.test" });
const test = require("node:test");
const assert = require("node:assert/strict");
const request = require("supertest");

const app = require("../src/app");

test("GET /api/health: 200 y { status: 'ok' }, sin autenticación", async () => {
  const res = await request(app).get("/api/health");
  assert.equal(res.status, 200);
  assert.deepEqual(res.body, { status: "ok" });
});

test("GET /: sirve el dashboard estático (public/index.html)", async () => {
  const res = await request(app).get("/");
  assert.equal(res.status, 200);
  assert.match(res.headers["content-type"], /text\/html/);
  assert.match(res.text, /Programa Baja de Peso/);
});

test("helmet: la respuesta trae Content-Security-Policy restringida a 'self'", async () => {
  const res = await request(app).get("/api/health");
  const csp = res.headers["content-security-policy"];
  assert.ok(csp, "debería existir la cabecera Content-Security-Policy");
  assert.match(csp, /default-src 'self'/);
});

// El loginLimiter (20/15min) es más estricto que el apiLimiter general
// (300/15min) que también corre sobre /api/auth/login — este test confirma
// que el límite específico de login realmente se aplica y corta ANTES de
// llegar a 300, no solo en teoría.
test("loginLimiter: se agota a las 20 peticiones a /api/auth/login, antes que el límite general de 300", async () => {
  let lastStatus;
  for (let i = 0; i < 21; i++) {
    const res = await request(app).post("/api/auth/login").send({ email: "no-existe@test.com", password: "loquesea" });
    lastStatus = res.status;
    if (i < 20) {
      assert.notEqual(res.status, 429, `no debería estar limitado todavía en el intento #${i + 1}`);
    }
  }
  assert.equal(lastStatus, 429, "el intento #21 debería estar bloqueado por loginLimiter");
});
