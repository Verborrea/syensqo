// Pruebas de integración de db/create-doctor.js contra baja_de_peso_test.
// El script se corre como proceso hijo (así se prueba tal cual lo ejecuta un
// operador real por línea de comandos), pero con DATABASE_URL ya fijado a la
// base de test en el entorno del hijo — el propio script hace
// require("dotenv").config() sin path (carga .env por defecto), pero dotenv
// no pisa una variable que ya esté seteada, así que la del entorno del hijo
// gana y nunca toca baja_de_peso.
require("dotenv").config({ path: ".env.test" });
const test = require("node:test");
const assert = require("node:assert/strict");
const path = require("path");
const { execFileSync } = require("node:child_process");
const bcrypt = require("bcryptjs");

const pool = require("../src/db");

const SCRIPT = path.join(__dirname, "..", "db", "create-doctor.js");

test.before(async () => {
  await pool.query("TRUNCATE TABLE doctors, patients, evaluations CASCADE");
});

test.after(async () => {
  await pool.end();
});

function run(args) {
  try {
    const stdout = execFileSync("node", [SCRIPT, ...args], { env: process.env, encoding: "utf8" });
    return { code: 0, stdout, stderr: "" };
  } catch (err) {
    return { code: err.status, stdout: err.stdout || "", stderr: err.stderr || "" };
  }
}

test("create-doctor.js: sin argumentos, sale con error y muestra el uso", () => {
  const res = run([]);
  assert.notEqual(res.code, 0);
  assert.match(res.stderr, /Uso: node db\/create-doctor\.js/);
});

test("create-doctor.js: contraseña de menos de 8 caracteres, sale con error", () => {
  const res = run(["Dr. Corto", "corto@test.com", "1234567"]);
  assert.notEqual(res.code, 0);
  assert.match(res.stderr, /al menos 8 caracteres/);
});

test("create-doctor.js: crea la cuenta, hashea la contraseña, normaliza el email a minúsculas", async () => {
  const res = run(["Dr. Nuevo", "Nuevo@Test.COM", "unaContraseñaLarga"]);
  assert.equal(res.code, 0);
  assert.match(res.stdout, /Cuenta lista/);

  const { rows } = await pool.query(
    "SELECT full_name, email, password_hash FROM doctors WHERE email = $1",
    ["nuevo@test.com"]
  );
  assert.equal(rows.length, 1);
  assert.equal(rows[0].full_name, "Dr. Nuevo");
  const ok = await bcrypt.compare("unaContraseñaLarga", rows[0].password_hash);
  assert.ok(ok, "la contraseña guardada debería verificar contra la original vía bcrypt");
});

test("create-doctor.js: correr de nuevo con el mismo email actualiza en vez de duplicar", async () => {
  run(["Dr. Nuevo", "nuevo@test.com", "otraContraseñaLarga"]);

  const { rows } = await pool.query(
    "SELECT full_name, password_hash FROM doctors WHERE email = $1",
    ["nuevo@test.com"]
  );
  assert.equal(rows.length, 1, "no debería haber quedado una cuenta duplicada");
  const okOld = await bcrypt.compare("unaContraseñaLarga", rows[0].password_hash);
  const okNew = await bcrypt.compare("otraContraseñaLarga", rows[0].password_hash);
  assert.equal(okOld, false, "la contraseña vieja ya no debería servir");
  assert.equal(okNew, true, "debería verificar contra la contraseña nueva");
});
