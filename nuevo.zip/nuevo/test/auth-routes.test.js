// Pruebas de integración de /api/auth/* contra baja_de_peso_test (NUNCA la
// base real) — usa supertest para llamar a la app de Express sin abrir un
// puerto de red.
require("dotenv").config({ path: ".env.test" });
const test = require("node:test");
const assert = require("node:assert/strict");
const request = require("supertest");
const bcrypt = require("bcryptjs");

const pool = require("../src/db");
const app = require("../src/app");

test.before(async () => {
  await pool.query("TRUNCATE TABLE doctors, patients, evaluations CASCADE");
  const hash = await bcrypt.hash("ClaveDePrueba123", 4); // costo bajo: más rápido, no es la app real
  await pool.query(
    "INSERT INTO doctors (full_name, email, password_hash) VALUES ('Dra. Test', 'test@test.com', $1)",
    [hash]
  );
});

test.after(async () => {
  await pool.end();
});

test("POST /api/auth/login: 400 sin email/password", async () => {
  const res = await request(app).post("/api/auth/login").send({});
  assert.equal(res.status, 400);
});

test("POST /api/auth/login: 401 con email inexistente", async () => {
  const res = await request(app).post("/api/auth/login").send({ email: "no-existe@test.com", password: "loquesea" });
  assert.equal(res.status, 401);
});

test("POST /api/auth/login: 401 con password incorrecto", async () => {
  const res = await request(app).post("/api/auth/login").send({ email: "test@test.com", password: "incorrecta" });
  assert.equal(res.status, 401);
});

test("POST /api/auth/login: 200 y devuelve un JWT con credenciales correctas", async () => {
  const res = await request(app).post("/api/auth/login").send({ email: "test@test.com", password: "ClaveDePrueba123" });
  assert.equal(res.status, 200);
  assert.ok(res.body.token);
  assert.equal(res.body.doctor.email, "test@test.com");
  assert.equal(res.body.password_hash, undefined, "el hash de la contraseña nunca debe salir en la respuesta");
});

test("POST /api/auth/login: el email no distingue mayúsculas/minúsculas", async () => {
  const res = await request(app).post("/api/auth/login").send({ email: "TEST@TEST.COM", password: "ClaveDePrueba123" });
  assert.equal(res.status, 200);
});

test("GET /api/auth/me: 401 sin token", async () => {
  const res = await request(app).get("/api/auth/me");
  assert.equal(res.status, 401);
});

test("GET /api/auth/me: 200 y devuelve el doctor con un token válido", async () => {
  const login = await request(app).post("/api/auth/login").send({ email: "test@test.com", password: "ClaveDePrueba123" });
  const res = await request(app).get("/api/auth/me").set("Authorization", "Bearer " + login.body.token);
  assert.equal(res.status, 200);
  assert.equal(res.body.email, "test@test.com");
});
