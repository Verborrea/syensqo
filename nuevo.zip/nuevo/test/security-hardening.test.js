// Simula ataques/errores comunes reportados en proyectos similares
// (Express + PostgreSQL + JWT) contra esta app, contra baja_de_peso_test.
require("dotenv").config({ path: ".env.test" });
const test = require("node:test");
const assert = require("node:assert/strict");
const request = require("supertest");
const bcrypt = require("bcryptjs");

const pool = require("../src/db");
const app = require("../src/app");

let token;
let doctorId;
let doctorEmail = "doctora@test.com";

test.before(async () => {
  await pool.query("TRUNCATE TABLE doctors, patients, evaluations CASCADE");
  const hash = await bcrypt.hash("ClaveDePrueba123", 4);
  const { rows } = await pool.query(
    "INSERT INTO doctors (full_name, email, password_hash) VALUES ('Dra. Test', $1, $2) RETURNING id",
    [doctorEmail, hash]
  );
  doctorId = rows[0].id;
  const login = await request(app).post("/api/auth/login").send({ email: doctorEmail, password: "ClaveDePrueba123" });
  token = login.body.token;
});

test.after(async () => {
  await pool.end();
});

// HALLAZGO buscado en GitHub: ataque clásico de "alg: none" contra JWT — un
// token sin firma, con el algoritmo declarado como "none", que algunas
// librerías/mal configuradas aceptan como válido.
test("JWT forjado con alg:none es rechazado (no autentica)", async () => {
  const header = Buffer.from(JSON.stringify({ alg: "none", typ: "JWT" })).toString("base64url");
  const payload = Buffer.from(JSON.stringify({ sub: doctorId, email: doctorEmail })).toString("base64url");
  const forged = `${header}.${payload}.`;

  const res = await request(app).get("/api/patients").set("Authorization", "Bearer " + forged);
  assert.equal(res.status, 401);
});

// HALLAZGO buscado en GitHub: Express body-parser sin límite de tamaño puede
// dejar pasar payloads gigantes (DoS/agotamiento de memoria). express.json()
// trae un límite de 100kb por defecto — se confirma que sigue activo.
test("payload JSON de más de 100kb: 413", async () => {
  const hugeBody = { full_name: "x".repeat(200 * 1024), height_m: 1.7 };
  const res = await request(app).post("/api/patients").send(hugeBody);
  assert.equal(res.status, 413);
});

test("JSON mal formado en el body: 400", async () => {
  const res = await request(app)
    .post("/api/patients")
    .set("Content-Type", "application/json")
    .send('{"full_name": "sin cerrar' );
  assert.equal(res.status, 400);
});

// HALLAZGO buscado en GitHub: inyección SQL clásica contra endpoints que
// reciben texto libre. Todas las queries de esta app usan parámetros ($1,
// $2...), así que un payload de SQLi debería guardarse como texto literal,
// no ejecutarse.
test("intento de inyección SQL en full_name se guarda como texto literal, no se ejecuta", async () => {
  const payload = "Robert'); DROP TABLE patients;--";
  const res = await request(app)
    .post("/api/patients")
    .set("Authorization", "Bearer " + token)
    .send({ full_name: payload, height_m: 1.7 });
  assert.equal(res.status, 201);
  assert.equal(res.body.full_name, payload);

  // si la tabla hubiera sido borrada, esta consulta fallaría
  const { rows } = await pool.query("SELECT count(*)::int AS n FROM patients");
  assert.ok(rows[0].n >= 1, "la tabla patients debería seguir existiendo con datos");
});

// HALLAZGO buscado en GitHub: contaminación de prototipo (__proto__ en el
// body JSON) — común en apps que hacen merges profundos de objetos. Esta
// app no mergea el body en nada, así que no debería tener efecto, pero se
// confirma explícitamente.
test("body con __proto__ no contamina Object.prototype", async () => {
  await request(app)
    .post("/api/patients")
    .set("Authorization", "Bearer " + token)
    .send(JSON.parse('{"full_name":"Proto Test","height_m":1.7,"__proto__":{"polluted":"si"}}'));

  assert.equal({}.polluted, undefined);
  assert.equal(Object.prototype.polluted, undefined);
});

// HALLAZGO buscado en GitHub: mass assignment / campos no esperados en el
// body (ej. intentar auto-asignarse como created_by o inyectar un id fijo).
test("intento de mass assignment (id, created_by) en el body es ignorado", async () => {
  const fakeId = "11111111-1111-1111-1111-111111111111";
  const res = await request(app)
    .post("/api/patients")
    .set("Authorization", "Bearer " + token)
    .send({ full_name: "Mass Assignment Test", height_m: 1.7, id: fakeId, created_by: fakeId, created_at: "1999-01-01" });
  assert.equal(res.status, 201);
  assert.notEqual(res.body.id, fakeId);
  const { rows } = await pool.query("SELECT created_by FROM patients WHERE id = $1", [res.body.id]);
  assert.equal(rows[0].created_by, doctorId, "created_by debe venir del token, no del body");
});

// HALLAZGO propio (no de GitHub): /api/patients/:id/evaluations coincidía a
// la vez con el mount de /api/patients (que no tenía ninguna ruta que
// matcheara y hacía next() en silencio) y con su propio mount aparte en
// app.js — consumiendo el rate limit compartido DOS veces y verificando el
// mismo JWT dos veces por request. Se arregló anidando evaluationsRouter
// dentro de patientsRouter. Esta prueba confirma que un solo request a
// evaluations consume exactamente 1 unidad del presupuesto, igual que
// cualquier otra ruta de /api/patients.
test("GET /api/patients/:id/evaluations consume exactamente 1 unidad del rate limit, no 2", async () => {
  const created = await request(app)
    .post("/api/patients")
    .set("Authorization", "Bearer " + token)
    .send({ full_name: "Paciente Rate Limit Test", height_m: 1.65 });
  const patientId = created.body.id;

  const before = await request(app).get("/api/patients").set("Authorization", "Bearer " + token);
  const remainingBefore = Number(before.headers["ratelimit-remaining"]);

  const after = await request(app)
    .get(`/api/patients/${patientId}/evaluations`)
    .set("Authorization", "Bearer " + token);
  const remainingAfter = Number(after.headers["ratelimit-remaining"]);

  assert.equal(remainingBefore - remainingAfter, 1, "un solo request a evaluations debería consumir 1 unidad, no 2");
});
