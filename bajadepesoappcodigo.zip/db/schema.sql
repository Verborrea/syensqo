CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS doctors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS patients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  birth_date DATE,
  sex TEXT CHECK (sex IN ('femenino', 'masculino', 'otro')),
  height_m NUMERIC(3,2) NOT NULL CHECK (height_m > 0.5 AND height_m < 2.5),
  created_by UUID REFERENCES doctors(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS evaluations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  eval_date DATE NOT NULL,
  peso_kg NUMERIC(5,2) NOT NULL CHECK (peso_kg > 0),
  fm_pct NUMERIC(4,1) NOT NULL CHECK (fm_pct >= 0 AND fm_pct <= 100),
  smm_kg NUMERIC(5,2) NOT NULL CHECK (smm_kg > 0),
  phase_angle NUMERIC(3,1) NOT NULL CHECK (phase_angle > 0),
  tbw_pct NUMERIC(4,1) NOT NULL CHECK (tbw_pct >= 0 AND tbw_pct <= 100),
  percentile_phase INT,
  is_manual BOOLEAN NOT NULL DEFAULT true,
  is_simulated BOOLEAN NOT NULL DEFAULT false,
  entered_by UUID REFERENCES doctors(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (patient_id, eval_date)
);

CREATE INDEX IF NOT EXISTS idx_evaluations_patient_date ON evaluations (patient_id, eval_date);
