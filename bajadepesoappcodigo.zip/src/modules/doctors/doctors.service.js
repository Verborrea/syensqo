// Módulo de doctores. Sin routes.js/controller.js a propósito: no existe
// ningún endpoint HTTP público sobre doctores (ni para crearlos ni para
// listarlos) — las cuentas se crean solo por línea de comandos
// (db/create-doctor.js), para que un doctor nunca pueda autoprovisionarse
// acceso. Este servicio es consumido por el módulo de auth (login/me) y por
// ese script de CLI.
const bcrypt = require("bcryptjs");
const pool = require("../../db");

async function findByEmail(email) {
  const { rows } = await pool.query(
    "SELECT id, full_name, email, password_hash FROM doctors WHERE email = $1",
    [String(email).toLowerCase().trim()]
  );
  return rows[0] || null;
}

async function findById(id) {
  const { rows } = await pool.query("SELECT id, full_name, email FROM doctors WHERE id = $1", [id]);
  return rows[0] || null;
}

async function createOrUpdate(fullName, email, password) {
  const passwordHash = await bcrypt.hash(password, 12);
  const { rows } = await pool.query(
    `INSERT INTO doctors (full_name, email, password_hash)
     VALUES ($1, $2, $3)
     ON CONFLICT (email) DO UPDATE SET full_name = EXCLUDED.full_name, password_hash = EXCLUDED.password_hash
     RETURNING id, full_name, email`,
    [fullName, String(email).toLowerCase().trim(), passwordHash]
  );
  return rows[0];
}

module.exports = { findByEmail, findById, createOrUpdate };
